import { useSelector, useDispatch } from 'react-redux';

export default function useAdmin() {
  const dispatch = useDispatch();

  return {};
}
