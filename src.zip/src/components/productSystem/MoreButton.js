import styled from "styled-components";
import { NormalButton } from "../../components/Button";
import useProduct from "../../hooks/productHooks/useProduct";
import { useLocation } from "react-router-dom";

const ButtonContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center:
`;

export const MoreButton = ({
  id,
  productCount,
  hasMoreProducts,
  products,
  handler,
}) => {
  //const location = useLocation();
  // const { productCount, products } = useProduct();
  // }

  return (
    <>
      {hasMoreProducts ? (
        <ButtonContainer>
          <NormalButton onClick={() => handler(id)}>看更多</NormalButton>
        </ButtonContainer>
      ) : (
        <></>
      )}
    </>
  );
};
