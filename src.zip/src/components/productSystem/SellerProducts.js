import styled from "styled-components";
import { COLOR, FONT, DISTANCE } from "../../constants/style";

export const SellerProductContainer = styled.section`
  display: flex;
  padding: 50px 42px;
`;

export const ProductsContainer = styled.div`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
`;

export const ProductsWrap = styled.div``;

export const ProductPicture = styled.div`
  background: url(${(props) => props.picture}) center/cover no-repeat;
  width: 190px;
  height: 190px;
`;

export const ProductContainer = styled.div`
  width: 190px;
  margin: 18px;
  margin-bottom: 50px;
`;

export const ProductName = styled.div`
  margin-top: ${DISTANCE.md};
  font-size: ${FONT.md};
  color: ${COLOR.black};
  text-align: center;
`;

export const VendorName = styled.div`
  margin-top: ${DISTANCE.sm};
  font-size: ${FONT.xs};
  color: ${COLOR.text_2};
  text-align: center;
`;

export const ProductPrice = styled.div`
  margin-top: 5px;
  font-size: ${FONT.xs};
  color: ${COLOR.text_2};
  text-align: center;

  &:before {
    content: "NT$ ";
  }
`;

export const Product = ({ product, vendorInfo }) => {
  return (
    <ProductContainer>
      <ProductPicture picture={product.picture_url} />
      <ProductName>{product.name}</ProductName>
      <VendorName>{vendorInfo.nickname}</VendorName>
      <ProductPrice>{product.price}</ProductPrice>
    </ProductContainer>
  );
};

export const SellerProducts = ({ products, vendorInfo }) => {
  // const handleClickProduct = (id) => {

  // }
  return (
    <>
      <SellerProductContainer>
        <ProductsWrap>
          <ProductsContainer>
            <>
              {products.map((product) => {
                return (
                  <Product
                    key={product.id}
                    product={product}
                    vendorInfo={vendorInfo}
                  />
                );
              })}
            </>
          </ProductsContainer>
        </ProductsWrap>
      </SellerProductContainer>
    </>
  );
};
