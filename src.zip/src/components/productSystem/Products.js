import styled from "styled-components";
import { COLOR, FONT, DISTANCE } from "../../constants/style";
import { MoreButton, ErrorMessage } from "../../components/productSystem/";
import useProduct from "../../hooks/productHooks/useProduct";

const ProductsContainer = styled.div`
  display: flex;
  padding: 50px 42px;
`;

const ProductsWrap = styled.div`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
`;

const ProductContainer = styled.div`
  position: relative;
  width: 190px;
  height: 190px;
  margin: 18px;
  margin-bottom: 150px;

  &:before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    width: 100%;
    background: url(${process.env.PUBLIC_URL}/logo-g.svg) center/cover;
  }
`;

const ProductPicture = styled.img`
  position: relative;
  width: 190px;
  height: 190px;
  transition: opacity 0.2s;
`;

const ProductName = styled.div`
  margin-top: ${DISTANCE.md};
  font-size: ${FONT.md};
  color: ${COLOR.black};
  text-align: center;
`;

const VendorName = styled.div`
  margin-top: ${DISTANCE.sm};
  font-size: ${FONT.xs};
  color: ${COLOR.text_2};
  text-align: center;
`;

const ProductPrice = styled.div`
  margin-top: 5px;
  font-size: ${FONT.xs};
  color: ${COLOR.text_2};
  text-align: center;

  &:before {
    content: "NT$ ";
  }
`;

const Product = ({ product, onLoad, loaded }) => {
  return (
    <ProductContainer>
      <ProductPicture
        src={product.picture_url}
        style={{ opacity: loaded ? 1 : 0 }}
        onLoad={onLoad}
      />
      <ProductName>{product.name}</ProductName>
      <VendorName>{product.User.nickname}</VendorName>
      <ProductPrice>{product.price}</ProductPrice>
    </ProductContainer>
  );
};

export const Products = ({
  products,
  id,
  hasMoreProducts,
  handler,
  productErrorMessage,
}) => {
  const { loaded, onLoad } = useProduct();
  // const handleClickProduct = (id) => {

  // }
  return (
    <>
      <ProductsContainer>
        <ProductsWrap>
          <>
            {products.map((product) => {
              return (
                <Product
                  key={product.id}
                  product={product}
                  onLoad={onLoad}
                  loaded={loaded}
                />
              );
            })}
          </>
        </ProductsWrap>
      </ProductsContainer>
      {loaded && !productErrorMessage ? (
        <MoreButton
          id={id}
          products={products}
          hasMoreProducts={hasMoreProducts}
          handler={handler}
        />
      ) : (
        <ErrorMessage productErrorMessage={productErrorMessage} />
      )}
    </>
  );
};
