import Footer from './Footer';
import Navbar from './Navbar';
import IconComponent from './Icon';
import Logo from './Logo';

export { Footer, Navbar, IconComponent, Logo };
