export { default } from './RulesPage';
