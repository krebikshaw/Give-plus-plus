import React from 'react';

const AdminUserPage = () => {
  return <div>AdminUserPage</div>;
};

export default AdminUserPage;
