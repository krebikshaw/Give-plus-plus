import React from 'react';

const AdminMailPage = () => {
  return <div>AdminMailPage</div>;
};

export default AdminMailPage;
