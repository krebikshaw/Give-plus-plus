export { default } from './AdminMailPage';
