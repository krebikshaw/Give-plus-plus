import React from 'react';

const AdminBackstagePage = () => {
  return <div>AdminBackstagePage</div>;
};

export default AdminBackstagePage;
