import AdminBackstagePage from './AdminBackstagePage';
import AdminMailPage from './AdminMailPage';
import AdminProductPage from './AdminProductPage';
import AdminUserPage from './AdminUserPage';

export { AdminBackstagePage, AdminMailPage, AdminProductPage, AdminUserPage };
