import React from 'react';

const AdminProductPage = () => {
  return <div>AdminProductPage</div>;
};

export default AdminProductPage;
