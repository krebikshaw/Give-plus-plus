export { default } from './AdminProductPage';
