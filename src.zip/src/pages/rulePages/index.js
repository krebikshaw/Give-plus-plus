import RulePage from './RulePage';
import RulesPage from './RulesPage';
export { RulePage, RulesPage };
