import CartPage from './CartPage';
import CheckoutPage from './CheckoutPage';

export { CartPage, CheckoutPage };
