export { default } from './FAQPage';
