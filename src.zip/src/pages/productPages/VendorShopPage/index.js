export { default } from './VendorShopPage';
