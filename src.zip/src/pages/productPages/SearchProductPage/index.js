export { default } from './SearchProductPage';
