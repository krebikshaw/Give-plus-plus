export { default } from './EditProductPage';
