import React from 'react';

const EditProductPage = () => {
  return <div>EditProductPage</div>;
};

export default EditProductPage;
