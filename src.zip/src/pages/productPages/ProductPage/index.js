export { default } from './ProductPage';
