import React, { useEffect } from "react";
import { Navbar } from "../../../components";
import { StandardNavPage } from "../../../components/Page";
import { COLOR, FONT, DISTANCE } from "../../../constants/style";
import styled from "styled-components";
import { NavLink, useParams, useNavigate } from "react-router-dom";
import useProduct from "../../../hooks/productHooks/useProduct";
import { useDispatch } from "react-redux";
import { ActionButton } from "../../../components/Button";
import {
  Products,
  MoreButton,
  ProductSort,
} from "../../../components/productSystem";
import {
  setProducts,
  setCategory,
  setHasMoreProducts,
  setErrorMessage,
} from "../../../redux/slices/productSlice/productSlice";

const BreadcrumbContainer = styled.section`
  margin-top: 180px;
`;

const BreadcrumbRoute = styled.nav`
  display: block;
`;

const BreadcrumbLi = styled.li`
  a {
    color: #007bff;
    display: inline-block;
    &:hover {
      color: ${COLOR.hover};
      text-decoration: underline;
    }
  }

  &:not(:first-child) {
    &:before {
      display: inline-block;
      padding-right: 0.5rem;
      padding-left: 0.5rem;
      color: #6c757d;
      content: "/";
    }
  }

  &:last-child {
    a {
      color: ${COLOR.black};
      cursor: none;
      text-decoration: none;
    }
  }
`;

const BreadcrumbOl = styled.ol`
  display: flex;
  flex-wrap: wrap;
  padding: 0.75rem 1rem 0.75rem 0;
  margin-bottom: 1rem;
  list-style: none;
`;
const Breadcrumb = () => {
  return (
    <BreadcrumbContainer>
      <BreadcrumbRoute>
        <BreadcrumbItems />
      </BreadcrumbRoute>
    </BreadcrumbContainer>
  );
};

const BreadcrumbItems = () => {
  return (
    <BreadcrumbOl>
      <BreadcrumbLi>
        <NavLink to='#'>Home</NavLink>
      </BreadcrumbLi>
      <BreadcrumbLi>
        <NavLink to='#'>Category</NavLink>
      </BreadcrumbLi>
      <BreadcrumbLi>
        <NavLink to='#'>Product</NavLink>
      </BreadcrumbLi>
    </BreadcrumbOl>
  );
};

const ProductInfoContainer = styled.section`
  margin-top: 20px;
  display: flex;
`;

const PurchaseInfoLeft = styled.section``;

const ProductPicture = styled.img`
  width: 620px;
  height: 410px;
  background: black;
  margin-bottom: 65px;
`;

const InfoTitle = styled.div`
  margin: ${DISTANCE.sm} auto;
  padding-bottom: ${DISTANCE.sm};
  font-size: ${FONT.lg};
  color: ${COLOR.text_2};
  border-bottom: 1px solid ${COLOR.text_2};
`;

const InfoBlock = styled.div`
  width: 400px;
  height: 100px;
  font-weight: bold;
  color: ${COLOR.black};
  white-space: pre-line;
  word-break: break-all;
`;

const ProductInfo = styled(InfoBlock)`
  height: 180px;
  font-weight: normal;
  color: ${COLOR.text_2};
`;

const Return = styled(NavLink)`
  color: #007bff;
  display: inline-block;
  &:hover {
    color: ${COLOR.hover};
    text-decoration: underline;
  }
`;

const InfoItem = styled.div`
  margin-top: ${DISTANCE.sm};
  display: flex;
  padding-bottom: ${DISTANCE.sm};
  &:not(:last-child) {
    border-bottom: 1px solid ${COLOR.text_2};
  }
`;
const InfoItemTitle = styled.div`
  width: 150px;
  padding-right: 20px;
  font-size: ${FONT.md};
  color: ${COLOR.text_2};
  word-break: break-all;
`;

const ProductIntro = () => {
  return (
    <>
      <InfoTitle>商品介紹</InfoTitle>
      <ProductInfo>* sadfasdfasdf * asdfasdf * dasfdsfasdf</ProductInfo>
    </>
  );
};

const FreightIntro = () => {
  return (
    <>
      <InfoTitle>運送方式與其他資訊</InfoTitle>
      <InfoItem>
        <InfoItemTitle>運送方式</InfoItemTitle>
        <InfoBlock>面交</InfoBlock>
      </InfoItem>
      <InfoItem>
        <InfoItemTitle>付款方式</InfoItemTitle>
        <InfoBlock>貨到付款</InfoBlock>
      </InfoItem>
      <InfoItem>
        <InfoItemTitle>退款換貨須知</InfoItemTitle>
        <Return to='#'>點我了解設計館的退款換貨須知</Return>
      </InfoItem>
    </>
  );
};

const PurchaseInfoRight = styled.section`
  margin-left: 100px;
`;

const ProductName = styled.div`
  width: 500px;
  word-break: break-all;
  font-weight: bold;
  font-size: ${FONT.md};
  color: ${COLOR.text_2};
`;

const ProductPrice = styled.div`
  margin-top: ${DISTANCE.md};
  font-weight: bold;
  font-size: ${FONT.xs};
  color: ${COLOR.text_1};

  &:before {
    content: "NT$ ";
  }
`;

const ProductQuantityContainer = styled.div`
  margin-top: ${DISTANCE.md};
  margin-bottom: 50px;
  label {
    display: block;
    font-size: ${FONT.xs};
    color: ${COLOR.text_2};
    margin-bottom: ${DISTANCE.sm};
  }
`;

const ProductCountSelect = styled.select`
  line-height: 1.4;
  font-size: 14px;
  color: #39393e;
  padding: 10px 14px 10px 14px;
  background-color: #fff;
  border: none;
  border-right: 14px solid #fff;
  box-shadow: 0 0 0 1px #d3d3d5;
  box-sizing: border-box;
  border-radius: 0;
  padding-right: 34px;
  margin: 1px;
  background-image: url(data:image/svg+xml,%3Csvg width='10' height='6' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 6'%3E%3Cpath class='color' d='M0 0h10L5 6z' fill='%23D3D3D5' fill-rule='evenodd'/%3E%3C/svg%3E%0A);
}
`;
const Options = () => {
  return (
    <>
      <option>1</option>
      <option>2</option>
      <option>3</option>
    </>
  );
};

const ProductQuantity = () => {
  return (
    <ProductQuantityContainer>
      <label>數量</label>
      <ProductCountSelect>
        <Options />
      </ProductCountSelect>
    </ProductQuantityContainer>
  );
};

const ShoppingCart = styled(ActionButton)`
  width: 430px;
`;

const RemindBlock = styled(InfoBlock)`
  margin-top: 20px;
  height: 100px;
  font-weight: normal;
  font-size: ${FONT.md};
  color: ${COLOR.text_2};
`;

const Remind = () => {
  return (
    <RemindBlock>
      付款後，從備貨到寄出商品為 1 個工作天。（不包含假日）
    </RemindBlock>
  );
};

const VendorInfoContainer = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`;

const VendorName = styled.div`
  font-size: ${FONT.md};
  color: ${COLOR.text_2};
`;

const VendorAvatar = styled.img`
  margin-right: 14px;
  width: 75px;
  height: 75px;
  border-radius: 50%;
`;

const VendorInfo = () => {
  return (
    <VendorInfoContainer>
      <VendorAvatar
        src={`https://i.pinimg.com/236x/c1/c4/bc/c1c4bc28dad9765a3b0e63d8553277cf.jpg`}
      />
      <VendorName>small-leaf</VendorName>
    </VendorInfoContainer>
  );
};

const VendorIntro = ({ product }) => {
  return (
    <>
      <InfoTitle>賣家</InfoTitle>
      <InfoItem>
        <VendorInfo />
      </InfoItem>
      <InfoItem>
        <InfoItemTitle>賣家其他商品</InfoItemTitle>
        <InfoBlock>貨到付款</InfoBlock>
      </InfoItem>
      <InfoItem>
        <InfoItemTitle>退款換貨須知</InfoItemTitle>
        <Return to='#'>點我了解設計館的退款換貨須知</Return>
      </InfoItem>
    </>
  );
};

const ProductPage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { id } = useParams();
  const {
    product,
    category,
    hasMoreProducts,
    productErrorMessage,
    handleClickCategoryMoreButton,
    handleGetProductFromCategory,
    handleGetProduct,
  } = useProduct();

  useEffect(() => {
    handleGetProduct(id);
    return () => {
      dispatch(setProducts([]));
      dispatch(setCategory([]));
      dispatch(setErrorMessage(null));
      dispatch(setHasMoreProducts(true));
    };
  }, []);
  return (
    <>
      <Navbar />
      <StandardNavPage>
        <Breadcrumb />
        <ProductInfoContainer>
          <PurchaseInfoLeft>
            <ProductPicture />
            <ProductIntro />
            <FreightIntro />
          </PurchaseInfoLeft>
          <PurchaseInfoRight>
            <ProductName>123456222222wwwwwwwwwwwwwwwwwwwwwwwwwwwww</ProductName>
            <ProductPrice>21316546</ProductPrice>
            <ProductQuantity />
            <ShoppingCart $margin={0} $size={"lg"}>
              放 入 購 物 車
            </ShoppingCart>
            <Remind />
            <VendorIntro product={product} />
          </PurchaseInfoRight>
        </ProductInfoContainer>
      </StandardNavPage>
    </>
  );
};

export default ProductPage;
