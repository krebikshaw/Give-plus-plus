export { default } from './PostProductPage';
