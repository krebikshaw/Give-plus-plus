import React from 'react';

const PostProductPage = () => {
  return <div>PostProductPage</div>;
};

export default PostProductPage;
