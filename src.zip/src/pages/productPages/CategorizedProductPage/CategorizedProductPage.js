import React, { useEffect } from "react";
import { Navbar } from "../../../components";
import { StandardNavPage } from "../../../components/Page";
import { IconComponent } from "../../../components/";
import { COLOR, FONT, DISTANCE } from "../../../constants/style";
import styled from "styled-components";
import { useDispatch } from "react-redux";
import { useParams, useNavigate } from "react-router-dom";
import useProduct from "../../../hooks/productHooks/useProduct";
import useUser from "../../../hooks/userHooks/useUser";

import {
  SellerProductContainer,
  ProductsContainer,
  ProductsWrap,
  ProductPicture,
  ProductContainer,
  ProductName,
  VendorName,
  ProductPrice,
  MoreButton,
} from "../../../components/productSystem";

const CategoryTitleContainer = styled.section`
  margin-top: 220px;
  display: flex;
  justify-content: space-between;
  color: ${COLOR.text_2};
`;

const CategoryName = styled.div`
  font-weight: bold;
  font-size: ${FONT.lg};
`;

const CategorySort = styled.div`
  display: flex;
  align-items: center;
  font-size: ${FONT.xs};
`;

const SortName = styled.div`
  margin-right: 40px;
`;

const Select = styled.select`
  width: 195px;
  padding: 15px 30px;
  color: ${COLOR.text_2};

  background: url(${process.env.PUBLIC_URL}/svg/angle-down.svg) no-repeat;
  background-position: right 5px top;
  -moz-appearance: none;
  -moz-appearance: none;
  -webkit-appearance: none;
  appearance: none;

  option {
    color: ${COLOR.text_2};
  }
`;

const SortSelect = () => {
  return (
    <Select>
      <option>最新上架優先</option>
    </Select>
  );
};

const CategoryTitle = () => {
  return (
    <CategoryTitleContainer>
      <CategoryName>分類：美妝</CategoryName>
      <CategorySort>
        <SortName>排序</SortName>
        <SortSelect />
      </CategorySort>
    </CategoryTitleContainer>
  );
};

const CategoryProductsContainer = styled(SellerProductContainer)``;

// const CategoryProductContainer = styled(ProductContainer)`
//   margin: 45px;
// `;
const CategoryProductsWrap = styled.div`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  align-items: flex-start;
`;

const Product = ({ product }) => {
  return (
    <ProductContainer>
      <ProductPicture picture={product.picture_url} />
      <ProductName>{product.name}</ProductName>
      <VendorName>{product.User.nickname}</VendorName>
      <ProductPrice>{product.price}</ProductPrice>
    </ProductContainer>
  );
};

const CategoryProducts = ({ products }) => {
  // const handleClickProduct = (id) => {

  // }
  return (
    <>
      <CategoryProductsContainer>
        <ProductsWrap>
          <ProductsContainer>
            <>
              {products.map((product) => {
                return <Product key={product.id} product={product} />;
              })}
            </>
          </ProductsContainer>
        </ProductsWrap>
      </CategoryProductsContainer>
    </>
  );
};

const CategorizedProductPage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { id } = useParams();
  const {
    products,
    productCount,
    hasMoreProducts,
    setProducts,
    productErrorMessage,
    handleClickCategoryMoreButton,
    handleGetProductFromCategory,
  } = useProduct();
  useEffect(() => {
    handleGetProductFromCategory(id, 1);
  }, []);
  console.log(products);
  return (
    <>
      <Navbar />
      <StandardNavPage>
        <CategoryTitle />
        <CategoryProducts products={products} />
        <MoreButton
          id={id}
          products={products}
          hasMoreProducts={hasMoreProducts}
          handler={handleClickCategoryMoreButton}
        />
      </StandardNavPage>
    </>
  );
};

export default CategorizedProductPage;
