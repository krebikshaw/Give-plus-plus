export { default } from './CategorizedProductPage';
