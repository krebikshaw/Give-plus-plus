import React from 'react';

const VendorOrdersPage = () => {
  return <div>VendorOrdersPage</div>;
};

export default VendorOrdersPage;
