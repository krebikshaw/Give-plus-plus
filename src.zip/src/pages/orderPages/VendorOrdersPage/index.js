export { default } from './VendorOrdersPage';
