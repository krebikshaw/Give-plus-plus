import ClientOrdersPage from './ClientOrdersPage';
import VendorOrdersPage from './VendorOrdersPage';
import OrderDetailPage from './OrderDetailPage';

export { ClientOrdersPage, VendorOrdersPage, OrderDetailPage };
