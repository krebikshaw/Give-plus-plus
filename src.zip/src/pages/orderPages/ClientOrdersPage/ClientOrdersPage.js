import React from 'react';

const ClientOrdersPage = () => {
  return <div>ClientOrdersPage</div>;
};

export default ClientOrdersPage;
