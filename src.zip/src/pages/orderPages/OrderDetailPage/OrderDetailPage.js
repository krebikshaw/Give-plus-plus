import React from 'react';

const OrderDetailPage = () => {
  return <div>OrderDetailPage</div>;
};

export default OrderDetailPage;
