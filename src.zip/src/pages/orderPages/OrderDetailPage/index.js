export { default } from './OrderDetailPage';
