import React from 'react';

const VendorBackstagePage = () => {
  return <div>VendorBackstagePage</div>;
};

export default VendorBackstagePage;
