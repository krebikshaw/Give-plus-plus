export { default } from './VendorBackstagePage';
