import React from 'react';

const UserInfoPage = () => {
  return <div>UserInfoPage</div>;
};

export default UserInfoPage;
