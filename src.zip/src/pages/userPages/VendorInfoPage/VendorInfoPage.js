import React from 'react';

const VendorInfoPage = () => {
  return <div>VendorInfoPage</div>;
};

export default VendorInfoPage;
