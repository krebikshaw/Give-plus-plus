export { default } from './VendorInfoPage';
