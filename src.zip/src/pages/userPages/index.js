import ApplyForVendorPage from './ApplyForVendorPage';
import UserInfoPage from './UserInfoPage';
import VendorBackstagePage from './VendorBackstagePage';
import VendorContactPage from './VendorContactPage';
import VendorInfoPage from './VendorInfoPage';

export {
  ApplyForVendorPage,
  UserInfoPage,
  VendorBackstagePage,
  VendorContactPage,
  VendorInfoPage,
};
