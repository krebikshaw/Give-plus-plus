export { default } from './VendorContactPage';
