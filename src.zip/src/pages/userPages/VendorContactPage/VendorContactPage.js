import React from 'react';

const VendorContactPage = () => {
  return <div>VendorContactPage</div>;
};

export default VendorContactPage;
