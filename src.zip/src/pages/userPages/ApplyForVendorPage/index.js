export { default } from './ApplyForVendorPage';
