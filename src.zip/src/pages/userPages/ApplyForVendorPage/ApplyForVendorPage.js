import React from 'react';

const ApplyForVendorPage = () => {
  return <div>ApplyForVendorPage</div>;
};

export default ApplyForVendorPage;
