export { default } from './EntrancePage';
