export { default } from './RegisterPage';
